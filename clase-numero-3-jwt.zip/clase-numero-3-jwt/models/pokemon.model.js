const db = [];
module.exports = db;