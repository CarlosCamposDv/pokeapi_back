const express = require('express');
const { getAll, getById, create, update, remove, getByType, statsByType, evolve, getStaticPokemons } = require('../controllers/pokemon.controller');
const authenticateToken = require('../middleware/auth.middleware');
const router = express.Router();

router.get('/', getAll);
router.get('/:id', getById);
router.post('/', authenticateToken, create);
router.put('/:id', authenticateToken, update);
router.delete('/:id', authenticateToken, remove);
router.get('/type/:type', getByType);
router.get('/stats/types', statsByType);
router.post('/:id/evolve', authenticateToken, evolve);
router.get('/static', getStaticPokemons);

module.exports = router;