const staticPokemons = [
    { name: 'Bulbasaur', type: 'Grass', level: 5 },
    { name: 'Charmander', type: 'Fire', level: 5 },
    { name: 'Squirtle', type: 'Water', level: 5 },
    { name: 'Pikachu', type: 'Electric', level: 5 },
    { name: 'Jigglypuff', type: 'Fairy', level: 4 },
];

exports.getStaticPokemons = () => {
    return staticPokemons;
};