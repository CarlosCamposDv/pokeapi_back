const jwt = require('jsonwebtoken');

let users = [];
const JWT_SECRET = "x3VRyTYorttgz_NlIHK-TcljbVgwEFYH0cjcE9FuJXs";

exports.register = (req, res) => {
    const { username, password } = req.body;

    if (!username || username.length < 3) {
        return res.status(400).json({ error: 'El nombre de usuario debe tener al menos 3 caracteres.' });
    }

    if (!password || password.length < 6) {
        return res.status(400).json({ error: 'La contraseña debe tener al menos 6 caracteres.' });
    }

    if (users.find(user => user.username === username)) {
        return res.status(400).json({ error: 'Usuario ya registrado' });
    }

    const newUser = { id: users.length + 1, username, password };
    users.push(newUser);

    const token = jwt.sign({ id: newUser.id, username: newUser.username }, JWT_SECRET, { expiresIn: '1h' });

    res.status(201).json({ message: 'Usuario registrado exitosamente', token });
};

exports.login = (req, res) => {
    const { username, password } = req.body;
    const user = users.find(u => u.username === username && u.password === password);
    if (!user) return res.status(400).json({ error: 'Credenciales inválidas' });

    const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: '1h' });
    res.json({ token });
};
