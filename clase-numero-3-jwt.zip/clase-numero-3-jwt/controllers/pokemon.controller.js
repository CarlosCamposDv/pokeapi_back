const db = require('../models/pokemon.model');
const staticPokemonService = require('../services/staticPokemon.service');

exports.getAll = (req, res) => {
    const { page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;
    const paginatedPokemons = db.slice(offset, offset + parseInt(limit));
    res.json({
        total: db.length,
        page: parseInt(page),
        limit: parseInt(limit),
        data: paginatedPokemons,
    });
};

exports.getById = (req, res) => {
    const pokemon = db.find(p => p.id === parseInt(req.params.id));
    if (!pokemon) return res.status(404).json({ error: 'Pokémon no encontrado' });
    res.json(pokemon);
};

exports.create = (req, res) => {
    const { name, type, level } = req.body;

    if (!name || typeof name !== 'string') {
        return res.status(400).json({ error: 'El nombre es obligatorio y debe ser una cadena de texto.' });
    }

    if (!type || typeof type !== 'string') {
        return res.status(400).json({ error: 'El tipo es obligatorio y debe ser una cadena de texto.' });
    }

    if (!level || typeof level !== 'number' || level < 1) {
        return res.status(400).json({ error: 'El nivel debe ser un número mayor o igual a 1.' });
    }

    const newPokemon = {
        id: db.length + 1,
        name,
        type,
        level,
        trainerId: req.user.id,
        createdAt: new Date(),
    };
    db.push(newPokemon);
    res.status(201).json(newPokemon);
};

exports.update = (req, res) => {
    const pokemon = db.find(p => p.id === parseInt(req.params.id));
    if (!pokemon) return res.status(404).json({ error: 'Pokémon no encontrado' });

    if (pokemon.trainerId !== req.user.id) return res.status(403).json({ error: 'No tienes permiso para actualizar este Pokémon' });

    const { name, type, level } = req.body;

    if (name && typeof name !== 'string') {
        return res.status(400).json({ error: 'El nombre debe ser una cadena de texto.' });
    }

    if (type && typeof type !== 'string') {
        return res.status(400).json({ error: 'El tipo debe ser una cadena de texto.' });
    }

    if (level && (typeof level !== 'number' || level < 1)) {
        return res.status(400).json({ error: 'El nivel debe ser un número mayor o igual a 1.' });
    }

    Object.assign(pokemon, { name, type, level });
    res.json(pokemon);
};

exports.remove = (req, res) => {
    const pokemonIndex = db.findIndex(p => p.id === parseInt(req.params.id));
    if (pokemonIndex === -1) return res.status(404).json({ error: 'Pokémon no encontrado' });

    const pokemon = db[pokemonIndex];
    if (pokemon.trainerId !== req.user.id) return res.status(403).json({ error: 'No tienes permiso para eliminar este Pokémon' });

    db.splice(pokemonIndex, 1);
    res.json({ message: 'Pokémon eliminado exitosamente' });
};

exports.getByType = (req, res) => {
    const type = req.params.type;
    const pokemonsByType = db.filter(p => p.type.toLowerCase() === type.toLowerCase());
    res.json(pokemonsByType);
};

exports.statsByType = (req, res) => {
    const stats = db.reduce((acc, pokemon) => {
        acc[pokemon.type] = (acc[pokemon.type] || 0) + 1;
        return acc;
    }, {});
    res.json(stats);
};

exports.evolve = (req, res) => {
    const pokemon = db.find(p => p.id === parseInt(req.params.id));
    if (!pokemon) return res.status(404).json({ error: 'Pokémon no encontrado' });

    if (pokemon.trainerId !== req.user.id) return res.status(403).json({ error: 'No tienes permiso para evolucionar este Pokémon' });

    pokemon.level += 1;
    pokemon.name = `Evolved-${pokemon.name}`;

    res.json({ message: 'Pokémon evolucionado exitosamente', pokemon });
};

exports.getStaticPokemons = (req, res) => {
    const staticPokemons = staticPokemonService.getStaticPokemons();
    res.json(staticPokemons);
};