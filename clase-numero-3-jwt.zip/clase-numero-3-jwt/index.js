const express = require('express');
const authRoutes = require('./routes/auth.routes');
const pokemonRoutes = require('./routes/pokemon.routes');

const app = express();
app.use(express.json());

// Configuración de rutas
app.use('/auth', authRoutes);
app.use('/pokemon', pokemonRoutes);

// Inicio del servidor
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Servidor escuchando en http://localhost:${PORT}`);
});
